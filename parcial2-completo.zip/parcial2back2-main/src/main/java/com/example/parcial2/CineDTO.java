package com.example.parcial2;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CineDTO {
    private Long id;
    private String nombre;
    private String ciudad;
}
